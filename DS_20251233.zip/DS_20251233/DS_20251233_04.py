from tkinter import *

root = Tk()